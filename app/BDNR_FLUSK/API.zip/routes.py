from flask import Blueprint, jsonify, request
from datetime import datetime
from BDNR_FLUSK.database import collection
from BDNR_FLUSK.models import Product

routes = Blueprint('routes', __name__)

@routes.route('/')
def home():
    return "Selamat datang di Product API!"

@routes.route('/api/v1/products', methods=['GET'])
def get_products():
    products = list(collection.find({}, {"_id": 0}))
    return jsonify(products)

@routes.route('/api/v1/products-add', methods=['POST'])
def add_product():
    new_product = request.get_json()
    serialized_product = Product.serialize(new_product)

    collection.insert_one(serialized_product)
    return jsonify(serialized_product), 201

@routes.route('/api/v1/products/<string:id>', methods=['PUT'])
def update_product(id):
    updated_data = request.json
    updated_data['updatedAt'] = datetime.utcnow()

    result = collection.update_one({"_id": id}, {"$set": updated_data})

    if result.matched_count == 0:
        return jsonify({"error": "Product not found"}), 404

    updated_product = collection.find_one({"_id": id}, {"_id": 0})
    return jsonify(updated_product)

@routes.route('/api/v1/products/<string:id>', methods=['DELETE'])
def delete_product(id):
    result = collection.delete_one({"_id": id})

    if result.deleted_count == 0:
        return jsonify({"error": "Product not found"}), 404

    return jsonify({"message": "Product deleted successfully"})