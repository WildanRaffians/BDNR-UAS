from datetime import datetime

class Product:
    @staticmethod
    def serialize(product):
        return {
            "name": product.get("name"),
            "price": product.get("price"),
            "description": product.get("description"),
            "createdAt": product.get("createdAt", datetime.utcnow()),
            "updatedAt": product.get("updatedAt", datetime.utcnow()),
        }
